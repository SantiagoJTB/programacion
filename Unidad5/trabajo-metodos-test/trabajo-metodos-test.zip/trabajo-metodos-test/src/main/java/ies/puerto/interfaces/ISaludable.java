package ies.puerto.interfaces;

public interface ISaludable {
    public int fechaCaducidad();
    public boolean caducado();
}
